const CONFIG = {
  BASE_URL: 'https://nutrition-calculator.p.rapidapi.com/api',
  CACHE_NAME: new Date().toISOString(),
};

export default CONFIG;
