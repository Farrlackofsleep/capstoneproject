import API_ENDPOINT from '../globals/api-endpoint';

class NutritionSource {
  static async bmi(cm, kilos) {
    const response = await fetch(
      API_ENDPOINT.BMI(cm, kilos),
      {
        method: 'GET',
        headers: {
          'x-rapidapi-key': '116261694emsh2d87bce118609e2p1f4dd9jsnd26b98048ed2',
        },
      },
    );
    return response.json();
  }

  static async nutritionInfo(gender, age, cm, kilos) {
    const response = await fetch(
      API_ENDPOINT.NUTRITION_INFO(gender, age, cm, kilos),
      {
        method: 'GET',
        headers: {
          'x-rapidapi-key': '116261694emsh2d87bce118609e2p1f4dd9jsnd26b98048ed2',
        },
      },
    );
    return response.json();
  }
}

export default NutritionSource;
