import CONFIG from '../../globals/config';

const createDataCalculateNutritionInfoTemplate = (nutrition) => `
    <h2 class="capstone__title">Perkiraan Kebutuhan Kalori Harian: ${nutrition.BMI_EER['Estimated Daily Caloric Needs']}</h2>
    <div class="capstone__info">
        <h3>Recommended Intake Per Day</h3>
        <h4>Carbohydrate</h4>
        <p>${nutrition.macronutrients_table['macronutrients-table'][1][1]}</p>
        <h4>Protein</h4>
        <p>${nutrition.macronutrients_table['macronutrients-table'][3][1]}</p>
        <h4>Fat</h4>
        <p>${nutrition.macronutrients_table['macronutrients-table'][4][1]}</p>
        <h4>Total Water</h4>
        <p>${nutrition.macronutrients_table['macronutrients-table'][10][1]}</p>
    </div>
`;

const createDataCalculateBMITemplate = (bmi) => `
    <h2 class="capstone__title">BMI : ${bmi.bmi}</h2>
`;

export {
  createDataCalculateNutritionInfoTemplate,
  createDataCalculateBMITemplate,
};
