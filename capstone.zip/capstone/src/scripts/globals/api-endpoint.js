import CONFIG from './config';

const API_ENDPOINT = {
  BMI: (cm, kilos) => `${CONFIG.BASE_URL}/bmi?measurement_units=met&cm=${cm}&kilos=${kilos}`,
  NUTRITION_INFO: (gender, cm, kilos, age) => `${CONFIG.BASE_URL}/nutrition-info?measurement_units=met&sex=${gender}&age_value=${age}&age_type=yrs&cm=${cm}&kilos=${kilos}`,
};

export default API_ENDPOINT;
