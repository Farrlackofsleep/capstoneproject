import Bmi from '../views/pages/bmi';
import NutritionInfo from '../views/pages/nutrition-info';

const routes = {
  '/': Bmi, // default Page
  '/bmi': Bmi,
  '/nutrition-info': NutritionInfo,
};

export default routes;
