import NutritionSource from '../../data/nutrition-source';
import { createDataCalculateNutritionInfoTemplate } from '../templates/template-creator';

const NutritionInfo = {
  async render() {
    return `
      <div class="content">
        <div class="input-box">
          <h2 class="content__heading">NUTRITION INFO</h2>
          <div>
            <h3>Jenis Kelamin</h3>
            <select name="gender" id="gender">
              <option value="male">Laki - Laki</option>
              <option value="famale">Perempuan</option>
            </select>
          </div>
          <div>
            <h3>Tinggi Badan (cm)</h3>
            <input type="number" id="cm" placeholder="160">
          </div>
          <div>
            <h3>Berat Badan (kg)</h3>
            <input type="number" id="kilos" placeholder="60">
          </div>
          <div>
            <h3>Usia</h3>
            <input type="number" id="age" placeholder="30">
          </div>
          <button id="inputButton" class="button-input" type="submit">Calculate</button>
          <div id="dataCalculate"></div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    document.getElementById('inputButton').addEventListener('click', async () => {
      // dapatkan nilai input
      const jenisKelamin = document.getElementById('gender').value.trim();
      const tinggi = document.getElementById('cm').value.trim();
      const berat = document.getElementById('kilos').value.trim();
      const usia = document.getElementById('age').value.trim();

      if (jenisKelamin !== '' && tinggi !== '' && berat !== '' && usia !== '') {
        const dataCalculate = document.getElementById('dataCalculate');

        dataCalculate.innerHTML = '';

        const nutrition = await NutritionSource.nutritionInfo(jenisKelamin, usia, tinggi, berat);

        dataCalculate.innerHTML = createDataCalculateNutritionInfoTemplate(nutrition);

        document.getElementById('cm').value = '';
        document.getElementById('kilos').value = '';
        document.getElementById('age').value = '';
      } else {
        // eslint-disable-next-line no-alert
        alert('Silakan isi data dengan lengkap');
      }
    });
  },
};

export default NutritionInfo;
