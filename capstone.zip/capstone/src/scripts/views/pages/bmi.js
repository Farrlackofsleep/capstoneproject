import NutritionSource from '../../data/nutrition-source';
import { createDataCalculateBMITemplate } from '../templates/template-creator';

const Bmi = {
  async render() {
    return `
      <div class="content">
        <div class="input-box" id="inputData">
            <h2 class="content__heading">BMI</h2>
            <div>
                <h3>Tinggi Badan (cm)</h3>
                <input type="number" id="cm" placeholder="160">
            </div>
            <div>
                <h3>Berat Badan (kg)</h3>
                <input type="number" id="kilos" placeholder="60">
            </div>
            <button id="inputButton" class="button-input" type="submit">Calculate</button>
        </div>
        <div id="dataCalculate"></div>
      </div>
    `;
  },

  async afterRender() {
    document.getElementById('inputButton').addEventListener('click', async () => {
      // dapatkan nilai input
      const tinggiBadan = document.getElementById('cm').value.trim();
      const beratBadan = document.getElementById('kilos').value.trim();

      if (tinggiBadan !== '' && beratBadan !== '') {
        const dataCalculate = document.getElementById('dataCalculate');

        dataCalculate.innerHTML = '';

        const bmi = await NutritionSource.bmi(tinggiBadan, beratBadan);

        dataCalculate.innerHTML = createDataCalculateBMITemplate(bmi);

        document.getElementById('cm').value = '';
        document.getElementById('kilos').value = '';
      } else {
        // eslint-disable-next-line no-alert
        alert('Silakan isi data dengan lengkap');
      }
    });
  },
};

export default Bmi;
